/**
 * PhantomShield - Embedded Surrogates Library
 * Minimalistic, functional stub scripts replacing blocked analytics and tracking libraries.
 */
(function() {
  const SURROGATES = {
    googleAnalytics: `
      (function() {
        var noopfn = function() {};
        var ga = function() {
          if (arguments.length > 0 && typeof arguments[arguments.length - 1] === 'function') {
            try { arguments[arguments.length - 1](); } catch(e) {}
          }
        };
        ga.create = function() { return { get: noopfn, set: noopfn, send: noopfn }; };
        ga.getByName = ga.create;
        ga.getAll = function() { return []; };
        ga.remove = noopfn;
        ga.loaded = true;
        window.ga = ga;
        window.gtag = noopfn;
      })();
    `,

    googleTagManager: `
      (function() {
        window.dataLayer = window.dataLayer || [];
        window.dataLayer.hide = { end: function() {}, start: function() {} };
        window.dataLayer.push = function(obj) {
          if (typeof obj === 'object' && obj && obj.eventCallback) {
            try { obj.eventCallback(); } catch(e) {}
          }
          return Array.prototype.push.apply(this, arguments);
        };
      })();
    `,

    facebookPixel: `
      (function() {
        var fbq = function() {
          fbq.callMethod ? fbq.callMethod.apply(fbq, arguments) : fbq.queue.push(arguments);
        };
        fbq.push = fbq;
        fbq.loaded = true;
        fbq.version = '2.0';
        fbq.queue = [];
        window.fbq = fbq;
        window._fbq = fbq;
      })();
    `
  };

  if (typeof window !== "undefined") {
    window.PHANTOM_SURROGATES = SURROGATES;
  }
  if (typeof globalThis !== "undefined") {
    globalThis.PHANTOM_SURROGATES = SURROGATES;
  }
})();
