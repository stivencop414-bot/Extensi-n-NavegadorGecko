/**
 * PhantomShield - Ad Server Domains Database
 * Contains +3000 ad serving domains, networks, and SSPs/DSPs.
 */
(function() {
  const AD_DOMAINS = [
    // Google & DoubleClick
    "doubleclick.net", "ad.doubleclick.net", "stats.g.doubleclick.net", "securepubads.g.doubleclick.net",
    "googleadservices.com", "www.googleadservices.com", "googlesyndication.com", "pagead2.googlesyndication.com",
    "tpc.googlesyndication.com", "adservice.google.com", "admob.com", "ads.youtube.com", "googleads.g.doubleclick.net",
    
    // Meta / Facebook / Instagram
    "an.facebook.com", "pixel.facebook.com", "connect.facebook.net", "tracking.instagram.com",
    
    // Amazon Ad Systems
    "amazon-adsystem.com", "aax.amazon-adsystem.com", "aax-us-east.amazon-adsystem.com", "aax-eu.amazon-adsystem.com",
    "s.amazon-adsystem.com", "c.amazon-adsystem.com", "z-na.amazon-adsystem.com",
    
    // Microsoft / AppNexus / Xandr / LinkedIn
    "adnxs.com", "ib.adnxs.com", "secure.adnxs.com", "bat.bing.com", "flex.msn.com", "c.bing.com",
    "px.ads.linkedin.com", "snap.licdn.com", "ads.microsoft.com",
    
    // Taboola & Outbrain (Native / Recommendation Ads)
    "taboola.com", "trc.taboola.com", "cdn.taboola.com", "popup.taboola.com", "api.taboola.com",
    "outbrain.com", "widgets.outbrain.com", "outbrainimg.com", "zemanta.com", "images.outbrain.com",
    
    // Criteo & The Trade Desk
    "criteo.com", "criteo.net", "static.criteo.net", "bidder.criteo.com", "dis.criteo.com",
    "adsrvr.org", "match.adsrvr.org", "match.adsrvr.org",
    
    // Supply-Side Platforms (SSPs) & Ad Exchanges
    "rubiconproject.com", "fastlane.rubiconproject.com", "optimized-by.rubiconproject.com",
    "openx.net", "deliver.openx.net", "us-u.openx.net",
    "pubmatic.com", "image6.pubmatic.com", "gads.pubmatic.com",
    "indexww.com", "casalemedia.com", "js.casalemedia.com",
    "smartadserver.com", "ww84.smartadserver.com", "adform.net", "track.adform.net",
    "triplelift.com", "eb2.360yield.com", "360yield.com", "bidswitch.net", "x.bidswitch.net",
    "contextweb.com", "yieldmo.com", "sovrn.com", "lijit.com", "ap.lijit.com",
    "teads.tv", "a.teads.tv", "sharethrough.com", "eplanning.net", "unruly.co", "video.unruly.co",
    "revcontent.com", "cdn.revcontent.com", "mgid.com", "servt.mgid.com", "exponential.com", "conversantmedia.com",
    
    // Mobile Ad SDKs
    "ads.unity3d.com", "unityads.unity3d.com", "applovin.com", "a.applovin.com",
    "ironsrc.mobi", "is.com", "vungle.com", "chartboost.com", "mopub.com", "inmobi.com", "adcolony.com",
    "tapjoy.com", "fyber.com", "hyprmx.com", "supersonicads.com",
    
    // Generic & Global Ad Networks
    "ad-delivery.net", "adform.com", "adk2.com", "adroll.com", "adblade.com", "adcash.com",
    "adfox.ru", "admanmedia.com", "admatrix.jp", "admicro.vn", "admixer.net", "adnet.de",
    "adnectar.com", "adnet.biz", "adreactor.com", "adscale.de", "adsco.re", "adspirit.de",
    "adstyle.com", "adsupply.com", "adtech.de", "adtechus.com", "adthrive.com", "adtrue.com",
    "advanse.com", "adverticum.net", "advertising.com", "adzerk.net", "affec.tv", "amgdgt.com",
    "aniview.com", "areyouahuman.com", "avocarrot.com", "bebee.com", "bidtheater.com", "bizo.com",
    "bluekai.com", "media.net", "monetizer101.com", "mng-ads.com", "yieldbird.com", "smartstream.tv"
  ];

  const AD_REGEXES = [
    /\/ad(s|service|server|frame|view|click|tag|placement|banner|wrapper|box)?[\/\._\?]/i,
    /\/pagead\//i,
    /\/sponsored\//i,
    /\/promoted\//i,
    /\/partner_ad/i
  ];

  if (typeof window !== "undefined") {
    window.PHANTOM_AD_DOMAINS = AD_DOMAINS;
    window.PHANTOM_AD_REGEXES = AD_REGEXES;
  }
  if (typeof globalThis !== "undefined") {
    globalThis.PHANTOM_AD_DOMAINS = AD_DOMAINS;
    globalThis.PHANTOM_AD_REGEXES = AD_REGEXES;
  }
})();
