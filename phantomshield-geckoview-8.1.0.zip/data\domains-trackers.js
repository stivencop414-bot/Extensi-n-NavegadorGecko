/**
 * PhantomShield - Tracking & Telemetry Domains Database
 */
(function() {
  const TRACKER_DOMAINS = [
    // Google Analytics & Telemetry
    "google-analytics.com", "analytics.google.com", "ssl.google-analytics.com",
    "googletagmanager.com", "googletagservices.com", "firebase-settings.crashlytics.com",
    "app-measurement.com", "measurement.google.com",
    
    // Hotjar, Mixpanel, Segment, Analytics
    "hotjar.com", "static.hotjar.com", "script.hotjar.com", "vars.hotjar.com",
    "mixpanel.com", "api.mixpanel.com", "decide.mixpanel.com",
    "segment.io", "cdn.segment.com", "api.segment.io",
    "fullstory.com", "rs.fullstory.com", "edge.fullstory.com",
    "amplitude.com", "api.amplitude.com", "api2.amplitude.com",
    "scorecardresearch.com", "b.scorecardresearch.com", "sb.scorecardresearch.com",
    "quantserve.com", "pixel.quantserve.com", "edge.quantserve.com",
    "crazyegg.com", "script.crazyegg.com",
    "heap.io", "heapanalytics.com",
    "clarity.ms", "c.clarity.ms", "a.clarity.ms",
    "logrocket.com", "r.logrocket.io",
    "mouseflow.com", "cdn.mouseflow.com",
    "inspectlet.com", "hn.inspectlet.com",
    "sentry.io", "browser.sentry-cdn.com",
    "bugsnag.com", "notify.bugsnag.com",
    "newrelic.com", "bam.nr-data.net", "js-agent.newrelic.com",
    "datadoghq.com", "browser-intake-datadoghq.com",
    
    // User Profiling & DMP
    "exelator.com", "loadm.exelator.com",
    "krxd.net", "cdn.krxd.net", "beacon.krxd.net",
    "rlcdn.com", "api.rlcdn.com",
    "tapad.com", "pixel.tapad.com",
    "demdex.net", "fast.demdex.net", "dpm.demdex.net",
    "omtrdc.net", "sc.omtrdc.net",
    "chartbeat.com", "ping.chartbeat.net", "static.chartbeat.com",
    "kissmetrics.com", "trkn.us",
    "pendo.io", "cdn.pendo.io"
  ];

  if (typeof window !== "undefined") {
    window.PHANTOM_TRACKER_DOMAINS = TRACKER_DOMAINS;
  }
  if (typeof globalThis !== "undefined") {
    globalThis.PHANTOM_TRACKER_DOMAINS = TRACKER_DOMAINS;
  }
})();
