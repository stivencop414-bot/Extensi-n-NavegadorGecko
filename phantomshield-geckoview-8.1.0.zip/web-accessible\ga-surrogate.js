// PhantomShield - Google Analytics Surrogate Script
(function() {
  'use strict';
  var noopfn = function() {};
  var ga = function() {
    if (arguments.length > 0 && typeof arguments[arguments.length - 1] === 'function') {
      try { arguments[arguments.length - 1](); } catch(e) {}
    }
  };
  ga.create = function() { return { get: noopfn, set: noopfn, send: noopfn }; };
  ga.getByName = ga.create;
  ga.getAll = function() { return []; };
  ga.remove = noopfn;
  ga.loaded = true;
  window.ga = ga;
  window.gtag = noopfn;
})();
