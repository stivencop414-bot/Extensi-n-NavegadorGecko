// PhantomShield - Google Tag Manager Surrogate Script
(function() {
  'use strict';
  window.dataLayer = window.dataLayer || [];
  window.dataLayer.hide = { end: function() {}, start: function() {} };
  window.dataLayer.push = function(obj) {
    if (typeof obj === 'object' && obj && obj.eventCallback) {
      try { obj.eventCallback(); } catch(e) {}
    }
    return Array.prototype.push.apply(this, arguments);
  };
})();
