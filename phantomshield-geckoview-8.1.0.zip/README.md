# PhantomShield 8.1 para GeckoView

Extensión WebExtension MV2 integrada para GeckoView. La versión 8.1 prioriza bloqueo útil, controles reales y compatibilidad: evita alterar APIs globales de todas las páginas salvo cuando una función lo necesita y puede desactivarse.

## Qué incluye

- Bloqueo de red mediante dominios incluidos y listas EasyList, EasyPrivacy y uBlock filters.
- Ocultamiento visual reversible: al apagar el bloqueo, la hoja de estilos deja de aplicarse.
- Eliminación de parámetros de seguimiento habituales en navegaciones.
- Sustitutos locales para algunas bibliotecas de analítica, evitando errores de carga.
- Protección conservadora contra ventanas de redes popup conocidas.
- Limpieza y salto de anuncios de YouTube como mecanismo de mejor esfuerzo.
- Detección de publicaciones patrocinadas en Facebook e Instagram.
- Bypass de acortadores limitado a dominios conocidos y apagado por defecto.
- Privacidad de Canvas opcional y apagada por defecto.
- Detección CNAME opcional y apagada por defecto porque consulta un servicio DNS remoto.
- Compatibilidad anti-paywall opcional y apagada por defecto porque puede afectar sesiones.

Ningún bloqueador puede garantizar eliminar todos los anuncios de forma permanente: los sitios cambian con frecuencia. El panel muestra el estado real de la actualización y no simula resultados.

## Ajustes predeterminados

| Ajuste | Estado inicial | Motivo |
| --- | --- | --- |
| Bloqueo principal | Activado | Función central |
| Bypass de acortadores | Desactivado | Evita navegaciones inesperadas |
| Privacidad de Canvas | Desactivado | Puede afectar editores y pruebas gráficas |
| Detección CNAME | Desactivado | Envía el hostname consultado a DNS sobre HTTPS |
| Anti-paywall | Desactivado | Puede romper autenticación o contenido |

## Integración en Android

1. Copia esta carpeta completa dentro de:

       app/src/main/assets/extensions/phantomshield/

2. Comprueba que el URI termine en una barra:

       resource://android/assets/extensions/phantomshield/

3. Registra la extensión incorporada con el mismo identificador del manifiesto:

~~~kotlin
private fun installPhantomShield(runtime: GeckoRuntime) {
    val location = "resource://android/assets/extensions/phantomshield/"
    val extensionId = "phantomshield@geckoview.internal"

    runtime.webExtensionController
        .ensureBuiltIn(location, extensionId)
        .accept(
            { extension ->
                Log.i("PhantomShield", "Extensión activa: " + extension.id)
            },
            { error ->
                Log.e("PhantomShield", "No se pudo instalar la extensión", error)
            }
        )
}
~~~

GeckoView conserva las extensiones instaladas entre reinicios. ensureBuiltIn evita reinstalaciones innecesarias y actualiza la extensión cuando aumenta la versión de manifest.json.

## Estructura principal

    manifest.json
    background/
      background.js          Orquestación, ajustes y webRequest
      network-engine.js      Motor de reglas y excepciones
      filter-lists.js        Carga segura del subconjunto ABP compatible
      updater.js             Descarga, límites y reporte real
      cname-uncloaker.js     CNAME opcional mediante DoH
    content/
      content-script.js      Puente de ajustes aislado
      page-hooks.js          Hooks que deben ejecutarse en MAIN
      cosmetic-filter.js     Filtros visuales reversibles
      link-bypass.js         Bypass limitado a acortadores conocidos
      heuristic-vision.js    Patrocinados de Meta
    popup/
      popup.html
      popup.css
      popup.js

Los archivos antiguos de módulos experimentales se conservan por compatibilidad del árbol fuente, pero no se cargan desde manifest.json. La lógica activa está en los archivos enumerados arriba.

## Seguridad y privacidad

- No se ejecuta código remoto. Las listas descargadas se interpretan como reglas declarativas.
- El actualizador limita tamaño, tiempo de respuesta y formato antes de guardar una lista.
- Las reglas con semántica no implementada se omiten para evitar bloqueos demasiado amplios.
- La detección CNAME usa Cloudflare DNS sobre HTTPS únicamente si el usuario la activa.
- El bypass valida protocolo, credenciales y dominio antes de navegar.
- El permiso tabs fue eliminado porque no se utiliza.

## Comprobación rápida

1. Valida que manifest.json sea JSON válido.
2. Comprueba la sintaxis de todos los archivos JavaScript.
3. Instala la extensión en una compilación actual de GeckoView.
4. Verifica una página normal con el bloqueo encendido y apagado.
5. Fuerza la actualización desde el panel y confirma el resultado mostrado.
6. Prueba YouTube, inicio de sesión y reproducción multimedia antes de distribuir la app.

La entrada world: MAIN del manifiesto sigue el modelo actual de WebExtensions. Si una versión antigua de GeckoView rechaza esa propiedad, actualiza GeckoView para que los hooks de página funcionen correctamente.
