/**
 * PhantomShield V2.0 - Cosmetic Hiding Rules
 * CSS rules for visual element suppression and procedural rules for complex cases.
 */
(function() {
  const COSMETIC_RULES = {
    // YouTube Specific Selectors
    youtube: [
      "ytd-ad-slot-renderer",
      "ytd-promoted-sparkles-web-renderer",
      "ytd-promoted-video-renderer",
      "ytd-display-ad-renderer",
      "ytd-in-feed-ad-layout-renderer",
      "ytd-statement-banner-renderer",
      "ytd-banner-promo-renderer-background",
      "ytd-rich-item-renderer:has(#ad-badge)",
      "ytd-rich-item-renderer:has(ytd-ad-slot-renderer)",
      "ytd-companion-slot-renderer",
      "#player-ads",
      "#masthead-ad",
      ".ytd-merch-shelf-renderer",
      "ytd-watch-next-secondary-results-renderer ytd-ad-slot-renderer",
      ".ytp-ad-overlay-container",
      ".ytp-ad-overlay-image",
      ".ytp-ad-image-overlay",
      ".ytp-ad-message-container",
      ".ytp-ad-action-interstitial",
      ".ytp-ad-progress-bar-container",
      "ytd-enforcement-message-view-model",
      "yt-playability-error-supported-renderers:has(ytd-enforcement-message-view-model)"
    ],

    // Universal Ad Selectors
    generic: [
      ".ad-banner", ".ad-box", ".ad-container", ".ad-slot", ".ad-wrapper", ".ad_box",
      ".ad_container", ".ad_slot", ".ad_wrapper", ".adbanner", ".adbox", ".addiv",
      ".adframe", ".adheader", ".adholder", ".adlayer", ".adplacement", ".ads-container",
      ".adsbygoogle", ".adservice", ".adsidebar", ".adsense", ".adslot", ".adtext",
      ".adunit", ".adzone", "#ad-banner", "#ad-box", "#ad-container", "#ad-slot",
      "#ad-wrapper", "#ad_box", "#ad_container", "#ad_slot", "#adbanner", "#adbox",
      "#adheader", "#adholder", "#adlayer", "#adplacement", "#ads-container",
      "#adsbygoogle", "#adsense", "#adslot", "#adunit", "#adzone",
      "[id^='google_ads_iframe']", "[id^='div-gpt-ad']", "[class*='sponsored-post']",
      "[class*='promoted-content']", ".taboola-ad", ".outbrain-ad", ".revcontent-ad"
    ],

    // Procedural JS filters (evaluated when standard CSS fails)
    procedural: [
      { selector: '[role="article"]', pseudo: 'has-text', args: 'Promocionado' },
      { selector: '[role="article"]', pseudo: 'has-text', args: 'Patrocinado' },
      { selector: '[role="article"]', pseudo: 'has-text', args: 'Sponsored' }
    ]
  };

  if (typeof window !== "undefined") {
    window.PHANTOM_COSMETIC_RULES = COSMETIC_RULES;
  }
  if (typeof globalThis !== "undefined") {
    globalThis.PHANTOM_COSMETIC_RULES = COSMETIC_RULES;
  }
})();
