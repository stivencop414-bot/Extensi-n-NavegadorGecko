/**
 * PhantomShield - Popunder, Popup & Redirect Ad Networks Database
 * Blocks aggressive popunder and click-hijacking ad domains.
 */
(function() {
  const POPUP_DOMAINS = [
    // Major Popunder Networks
    "popads.net", "servt.popads.net", "c1.popads.net", "c2.popads.net",
    "popcash.net", "cdn.popcash.net",
    "exoclick.com", "main.exoclick.com", "syndication.exoclick.com",
    "juicyads.com", "js.juicyads.com",
    "propellerads.com", "propellerclicks.com", "pushpro.xyz",
    "hilltopads.com", "adsterra.com", "clickadu.com",
    "zeroredirect1.com", "trafficfactory.biz", "trafficjunky.net", "trafficjunky.com",
    "bidvertiser.com", "clksite.com", "popmyads.com",
    "adcash.com", "cdn.adcash.com", "display.adcash.com",
    "revenuehits.com", "directrev.com", "adf.ly", "bc.vc",
    "shorte.st", "ouo.io", "linkvertise.com",
    
    // Aggressive Redirect & Fake Alert / Captcha Popups
    "notification-hub.com", "pushnotifications.net", "allow-check.com",
    "robotcaptcha2024.top", "verifycaptcha.top", "fast-verify.com",
    "best-prize-online.life", "spin-win-gift.xyz", "clean-my-android-now.top",
    "update-browser-now.net", "security-alert-center.com"
  ];

  if (typeof window !== "undefined") {
    window.PHANTOM_POPUP_DOMAINS = POPUP_DOMAINS;
  }
  if (typeof globalThis !== "undefined") {
    globalThis.PHANTOM_POPUP_DOMAINS = POPUP_DOMAINS;
  }
})();
