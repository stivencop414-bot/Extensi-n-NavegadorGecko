/**
 * PhantomShield V4.0 - Scriptlet Engine
 * Injects dynamic scriptlets (uBO syntax) to neuter specific variables and JSON responses.
 */
(function() {
  'use strict';

  const scriptletEngine = function() {
    console.log('[PhantomShield Scriptlets] Engine initializing...');

    window.PhantomScriptlets = {
      // 1. set-constant: Sets a global variable to a specific primitive value, preventing modification.
      setConstant: function(propPath, value) {
        const parts = propPath.split('.');
        let obj = window;
        for (let i = 0; i < parts.length - 1; i++) {
          if (!obj[parts[i]]) obj[parts[i]] = {};
          obj = obj[parts[i]];
        }
        const prop = parts[parts.length - 1];
        try {
          Object.defineProperty(obj, prop, {
            value: value,
            writable: false,
            configurable: false
          });
        } catch (e) {}
      },

      // 2. abort-on-property-read: Throws an error to abort script execution when a specific property is read.
      abortOnPropertyRead: function(propPath) {
        const parts = propPath.split('.');
        let obj = window;
        for (let i = 0; i < parts.length - 1; i++) {
          if (!obj[parts[i]]) obj[parts[i]] = {};
          obj = obj[parts[i]];
        }
        const prop = parts[parts.length - 1];
        try {
          Object.defineProperty(obj, prop, {
            get: function() {
              throw new ReferenceError(`PhantomShield: Aborted read of ${propPath}`);
            },
            set: function() {}
          });
        } catch (e) {}
      },

      // 3. json-prune: Traverses a JSON object and deletes specified keys.
      jsonPrune: function(obj, keysToPrune) {
        if (!obj || typeof obj !== 'object') return;
        const keys = Array.isArray(keysToPrune) ? keysToPrune : keysToPrune.split(' ');
        
        const prune = (target) => {
          if (!target || typeof target !== 'object') return;
          if (Array.isArray(target)) {
            target.forEach(prune);
          } else {
            keys.forEach(key => {
              if (target[key] !== undefined) delete target[key];
            });
            Object.values(target).forEach(prune);
          }
        };
        prune(obj);
        return obj;
      }
    };

    // Apply known hardcoded scriptlets for specific sites (simulating uBO filter rules)
    const hostname = location.hostname;

    if (hostname.includes('youtube.com')) {
       // Example of pre-emptive scriptlet application for YouTube
       // Note: actual youtube defusing happens heavily in youtube-defuser.js for XHR interception
       // but we could set constants here if needed.
       window.PhantomScriptlets.setConstant('ytInitialPlayerResponse.adPlacements', undefined);
    }
  };

  const scriptEl = document.createElement('script');
  scriptEl.textContent = '(' + scriptletEngine.toString() + ')();';
  (document.head || document.documentElement).appendChild(scriptEl);
  scriptEl.remove();
})();
