/**
 * PhantomShield - YouTube Specific Ad Patterns & Endpoints
 */
(function() {
  const YOUTUBE_PATTERNS = {
    // Media stream query param flags for standalone client-side ads
    streamParams: [
      "adformat=",
      "ad_type=",
      "ctier=A",
      "pltype=contentad"
    ],

    // Specific endpoints to block/redirect
    blockedEndpoints: [
      "/pagead/gen_204",
      "/pagead/lvz",
      "/pagead/adview",
      "/pagead/conversion",
      "/api/stats/ads",
      "s.youtube.com/api/stats/ads",
      "video-stats.l.google.com",
      "googleads.g.doubleclick.net"
    ],

    // InnerTube API endpoints requiring JSON response sanitization
    targetApiEndpoints: [
      "/youtubei/v1/player",
      "/youtubei/v1/next",
      "/youtubei/v1/att/get",
      "/youtubei/v1/browse"
    ],

    // JSON keys to prune from API responses
    keysToPrune: [
      "adPlacements",
      "playerAds",
      "adSlots",
      "adBreaks",
      "promotedItem",
      "masthead",
      "enforcementMessageViewModel"
    ]
  };

  if (typeof window !== "undefined") {
    window.PHANTOM_YOUTUBE_PATTERNS = YOUTUBE_PATTERNS;
  }
  if (typeof globalThis !== "undefined") {
    globalThis.PHANTOM_YOUTUBE_PATTERNS = YOUTUBE_PATTERNS;
  }
})();
