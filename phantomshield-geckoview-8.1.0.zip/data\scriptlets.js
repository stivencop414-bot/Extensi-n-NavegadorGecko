/**
 * PhantomShield - Scriptlets Library
 * Code snippets injected into web pages to defuse anti-adblockers and override script properties.
 */
(function() {
  const SCRIPTLETS = {
    // Sets a global property on window
    setConstant: function(targetPath, value) {
      try {
        const parts = targetPath.split('.');
        let curr = window;
        for (let i = 0; i < parts.length - 1; i++) {
          if (!curr[parts[i]]) curr[parts[i]] = {};
          curr = curr[parts[i]];
        }
        const last = parts[parts.length - 1];
        Object.defineProperty(curr, last, {
          value: value,
          writable: false,
          configurable: true
        });
      } catch (e) {}
    },

    // Injects stub Google Publisher Tag
    defuseGoogleTag: function() {
      if (window.googletag && window.googletag.apiReady) return;
      window.googletag = window.googletag || {};
      window.googletag.cmd = window.googletag.cmd || [];
      window.googletag.apiReady = true;
      window.googletag.display = function() {};
      window.googletag.destroySlots = function() {};
      window.googletag.pubads = function() {
        return {
          addEventListener: function() {},
          clear: function() {},
          collapseEmptyDivs: function() {},
          disableInitialLoad: function() {},
          enableSingleRequest: function() {},
          enableServices: function() {},
          refresh: function() {},
          setTargeting: function() { return this; }
        };
      };
    },

    // Aborts scripts matching a regex or function name
    abortCurrentScript: function(propertyToMatch) {
      try {
        let original = window[propertyToMatch];
        Object.defineProperty(window, propertyToMatch, {
          get: function() {
            const stack = new Error().stack;
            if (stack && (stack.includes("adblock") || stack.includes("detect"))) {
              throw new Error("PhantomShield Defused Anti-Adblock");
            }
            return original;
          },
          set: function(val) {
            original = val;
          }
        });
      } catch (e) {}
    }
  };

  if (typeof window !== "undefined") {
    window.PHANTOM_SCRIPTLETS = SCRIPTLETS;
  }
  if (typeof globalThis !== "undefined") {
    globalThis.PHANTOM_SCRIPTLETS = SCRIPTLETS;
  }
})();
