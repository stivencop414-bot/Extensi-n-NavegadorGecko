(function() {
  'use strict';

  const DEFAULT_SETTINGS = {
    adblockEnabled: true,
    bypassEnabled: false,
    paywallEnabled: false,
    privacyEnabled: false,
    cnameEnabled: false,
    blockedCount: 0
  };

  const controlIds = {
    adblockEnabled: 'toggle-adblock',
    bypassEnabled: 'toggle-bypass',
    privacyEnabled: 'toggle-privacy',
    cnameEnabled: 'toggle-cname',
    paywallEnabled: 'toggle-paywall'
  };

  document.addEventListener('DOMContentLoaded', async function() {
    const blockedCount = document.getElementById('blocked-count');
    const updateButton = document.getElementById('btn-update');
    const status = document.getElementById('status');
    const numberFormatter = new Intl.NumberFormat('es-CO');

    function setStatus(message, kind) {
      status.textContent = message || '';
      if (kind) status.dataset.kind = kind;
      else delete status.dataset.kind;
    }

    function showCount(value) {
      const count = Number.isFinite(Number(value)) ? Number(value) : 0;
      blockedCount.textContent = numberFormatter.format(count);
    }

    try {
      const stored = await browser.storage.local.get(DEFAULT_SETTINGS);
      for (const key of Object.keys(controlIds)) {
        document.getElementById(controlIds[key]).checked = Boolean(stored[key]);
      }
      showCount(stored.blockedCount);
    } catch (error) {
      setStatus('No se pudieron cargar los ajustes.', 'error');
    }

    try {
      const response = await browser.runtime.sendMessage({ type: 'GET_STATS' });
      if (response && response.ok) {
        showCount(response.blockedCount);
        await browser.storage.local.set({ blockedCount: response.blockedCount });
      }
    } catch (error) {
      setStatus('El servicio de fondo no respondió.', 'error');
    }

    for (const key of Object.keys(controlIds)) {
      const control = document.getElementById(controlIds[key]);
      control.addEventListener('change', async function() {
        const item = {};
        item[key] = control.checked;
        try {
          await browser.storage.local.set(item);
          if (key === 'cnameEnabled' && control.checked) {
            setStatus('CNAME activo: las consultas se envían por DNS seguro.', 'success');
          } else if (key === 'privacyEnabled' && control.checked) {
            setStatus('Privacidad de Canvas activada. Recarga las pestañas abiertas.', 'success');
          } else {
            setStatus('Ajuste guardado.', 'success');
          }
        } catch (error) {
          control.checked = !control.checked;
          setStatus('No se pudo guardar el ajuste.', 'error');
        }
      });
    }

    updateButton.addEventListener('click', async function() {
      const originalText = updateButton.textContent;
      updateButton.disabled = true;
      updateButton.textContent = 'Actualizando…';
      setStatus('Descargando y validando las listas…');

      try {
        const result = await browser.runtime.sendMessage({ type: 'FORCE_UPDATE' });
        if (!result || !result.ok) {
          throw new Error(result && result.error ? result.error : 'Actualización fallida');
        }
        const summary = result.failed > 0
          ? 'Actualizadas: ' + result.updated + '. Fallidas: ' + result.failed + '.'
          : 'Listas actualizadas correctamente: ' + result.updated + '.';
        setStatus(summary, result.failed > 0 ? 'error' : 'success');
      } catch (error) {
        setStatus(error && error.message ? error.message : 'No se pudieron actualizar las listas.', 'error');
      } finally {
        updateButton.disabled = false;
        updateButton.textContent = originalText;
      }
    });
  });
})();
