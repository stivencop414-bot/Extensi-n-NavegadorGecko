/**
 * PhantomShield 8.1 - Filter-list updater.
 * Downloads declarative text only, applies size/time limits, and reports real results.
 */
(function() {
  'use strict';

  const LISTS = [
    { id: 'easylist', url: 'https://easylist.to/easylist/easylist.txt' },
    { id: 'easyprivacy', url: 'https://easylist.to/easylist/easyprivacy.txt' },
    { id: 'ubo-filters', url: 'https://raw.githubusercontent.com/uBlockOrigin/uAssets/master/filters/filters.txt' }
  ];

  class PhantomUpdater {
    constructor() {
      this.cacheKeyPrefix = 'phantom_list_';
      this.lastUpdateKey = 'phantom_last_update';
      this.updateIntervalHours = 24;
      this.maxListBytes = 15 * 1024 * 1024;
      this.requestTimeoutMs = 20000;
      this.updatePromise = null;
    }

    async start() {
      if (browser.alarms) {
        browser.alarms.create('updateFilterLists', {
          delayInMinutes: 15,
          periodInMinutes: this.updateIntervalHours * 60
        });
        browser.alarms.onAlarm.addListener((alarm) => {
          if (alarm.name === 'updateFilterLists') this.updateAllLists();
        });
      }

      const lastUpdate = Number(await this._getStorage(this.lastUpdateKey)) || 0;
      const ageHours = (Date.now() - lastUpdate) / 3600000;
      if (lastUpdate === 0 || ageHours >= this.updateIntervalHours) {
        return this.updateAllLists();
      }
      return {
        ok: true,
        updated: 0,
        failed: 0,
        skipped: LISTS.length,
        lastUpdate: lastUpdate
      };
    }

    updateAllLists() {
      if (this.updatePromise) return this.updatePromise;
      this.updatePromise = this._performUpdate().finally(() => {
        this.updatePromise = null;
      });
      return this.updatePromise;
    }

    async _performUpdate() {
      let updated = 0;
      let failed = 0;
      const errors = [];

      for (const list of LISTS) {
        try {
          const text = await this._downloadList(list);
          await this._setStorage(this.cacheKeyPrefix + list.id, text);
          updated++;
        } catch (error) {
          failed++;
          errors.push(list.id + ': ' + (error && error.message ? error.message : 'error desconocido'));
          console.warn('[PhantomShield Updater] ' + list.id + ' failed.', error);
        }
      }

      let lastUpdate = Number(await this._getStorage(this.lastUpdateKey)) || 0;
      if (updated > 0) {
        lastUpdate = Date.now();
        await this._setStorage(this.lastUpdateKey, lastUpdate);
        if (globalThis.PhantomFilterListManager) {
          await globalThis.PhantomFilterListManager.reloadFromStorage();
        }
      }

      return {
        ok: updated > 0,
        updated: updated,
        failed: failed,
        skipped: 0,
        lastUpdate: lastUpdate,
        errors: errors
      };
    }

    async _downloadList(list) {
      const controller = typeof AbortController === 'function' ? new AbortController() : null;
      const timeoutId = controller
        ? setTimeout(() => controller.abort(), this.requestTimeoutMs)
        : null;

      try {
        const response = await fetch(list.url, {
          cache: 'no-cache',
          credentials: 'omit',
          redirect: 'follow',
          signal: controller ? controller.signal : undefined
        });
        if (!response.ok) throw new Error('HTTP ' + response.status);

        const declaredSize = Number(response.headers.get('content-length')) || 0;
        if (declaredSize > this.maxListBytes) throw new Error('lista demasiado grande');

        const text = await response.text();
        if (text.length === 0 || text.length > this.maxListBytes) {
          throw new Error('tamaño de lista inválido');
        }
        const preview = text.slice(0, 1024);
        if (!preview.includes('\n') || /<html[\s>]/i.test(preview)) {
          throw new Error('respuesta no compatible con una lista de filtros');
        }
        return text;
      } finally {
        if (timeoutId !== null) clearTimeout(timeoutId);
      }
    }

    async _getStorage(key) {
      const result = await browser.storage.local.get(key);
      return result[key];
    }

    async _setStorage(key, value) {
      const item = {};
      item[key] = value;
      await browser.storage.local.set(item);
    }
  }

  globalThis.PhantomUpdaterInstance = new PhantomUpdater();
})();
